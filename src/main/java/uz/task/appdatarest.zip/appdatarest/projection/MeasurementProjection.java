package uz.task.appdatarest.projection;


public interface MeasurementProjection {

    long getId();

    String getName();

    boolean isActive();

}

