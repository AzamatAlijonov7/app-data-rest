package uz.task.appdatarest.projection;

public interface AttachmentContentProjection {
    long getId();

    byte[] getContent();
}
