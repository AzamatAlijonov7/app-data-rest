package uz.task.appdatarest.projection;

public interface AttachmentProjection {
    Long getId();
    String getName();
    Long getSize();
    String getContent_type();
}

