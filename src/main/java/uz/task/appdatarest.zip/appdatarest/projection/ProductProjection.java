package uz.task.appdatarest.projection;

public interface ProductProjection {
    Long getId();
    String getName();
    // add other attributes as needed
}

