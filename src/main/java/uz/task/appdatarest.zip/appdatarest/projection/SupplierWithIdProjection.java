package uz.task.appdatarest.projection;

public interface SupplierWithIdProjection {

    Long getId();

    String getName();

    boolean isActive();

    String getPhone_number();

}
