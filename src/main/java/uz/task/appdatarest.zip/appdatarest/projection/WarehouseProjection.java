package uz.task.appdatarest.projection;

public interface WarehouseProjection {

    Long getId();

    String getName();

    Boolean getActive();

}

