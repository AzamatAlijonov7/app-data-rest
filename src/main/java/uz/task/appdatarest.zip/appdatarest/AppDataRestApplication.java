package uz.task.appdatarest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppDataRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppDataRestApplication.class, args);
	}

}
