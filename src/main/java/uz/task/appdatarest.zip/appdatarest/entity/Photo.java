package uz.task.appdatarest.entity;

public class Photo {
}
